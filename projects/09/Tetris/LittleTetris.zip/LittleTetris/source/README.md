# Little Tetris

## run

1. open VMEmulator: `path/to/VMEmulator.sh`
2. select **load script** button and select `LittleTetris/Test.tst`
3. press Esc key to start play grame

## screen shot

![play screen shot](screen-shot.png)
